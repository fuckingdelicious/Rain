import { joinVoiceChannel, createAudioPlayer } from '@discordjs/voice';

export function createConnection(channel) {
    const connection = joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
    });

    const player = createAudioPlayer();

    return { connection, player };
}
