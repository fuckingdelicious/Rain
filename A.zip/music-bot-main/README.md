
# A Simple Discord Music Bot for You!

This repository contains a simple and efficient music bot for Discord, created by:

- **HeyArnoldo** (heyarnoldo on Discord)
- **Alejandrxxz** (gthc.alejandrx on Discord)

### Enjoy Great Programming!
