import { distube } from '../client.js';

export default {
    name: 'interactionCreate',
    async execute(interaction) {
        if (interaction.isCommand()) {
            const command = interaction.client.commands.get(interaction.commandName);

            if (!command) return;

            try {
                await command.default.execute(interaction);
            } catch (error) {
                console.error('Error executing command:', error);
                await interaction.reply({ 
                    content: '🚨 There was an error while executing this command!', 
                    ephemeral: true 
                });
            }
        } else if (interaction.isButton()) {
            const queue = distube.getQueue(interaction.guildId);

            // Check if there's a queue and if it's not empty
            if (!queue || queue.songs.length === 0) {
                return interaction.reply({ 
                    content: '❌ There is no song playing right now.', 
                    ephemeral: true 
                });
            }

            try {
                switch (interaction.customId) {
                    case 'pause':
                        if (!queue.paused) {
                            queue.pause();
                            interaction.reply({ 
                                content: '⏸️ Paused the music!', 
                                ephemeral: true 
                            });
                        } else {
                            interaction.reply({ 
                                content: 'The music is already paused!', 
                                ephemeral: true 
                            });
                        }
                        break;
                    case 'resume':
                        if (queue.paused) {
                            queue.resume();
                            interaction.reply({ 
                                content: '▶️ Resumed the music!', 
                                ephemeral: true 
                            });
                        } else {
                            interaction.reply({ 
                                content: 'The music is already playing!', 
                                ephemeral: true 
                            });
                        }
                        break;
                    case 'stop':
                        queue.stop();
                        interaction.reply({ 
                            content: '⏹️ Stopped the music and cleared the queue!', 
                            ephemeral: true 
                        });
                        break;
                    case 'skip':
                        if (queue.songs.length > 1) {
                            // Skip to the next song if there is one
                            queue.skip();
                            interaction.reply({ 
                                content: '⏭️ Skipped to the next song!', 
                                ephemeral: true 
                            });
                        } else {
                            // Stop the music if there are no more songs
                            queue.stop();
                            interaction.reply({ 
                                content: '🚨 No next song to skip to! Playback stopped.', 
                                ephemeral: true 
                            });
                        }
                        break;
                    case 'shuffle':
                        queue.shuffle();
                        interaction.reply({ 
                            content: '🔀 Shuffled the queue!', 
                            ephemeral: true 
                        });
                        break;
                    default:
                        interaction.reply({ 
                            content: 'Unknown action!', 
                            ephemeral: true 
                        });
                        break;
                }
            } catch (error) {
                console.error('Error handling button interaction:', error);
                interaction.reply({ 
                    content: '🚨 An error occurred while processing your request.', 
                    ephemeral: true 
                });
            }
        }
    },
};
