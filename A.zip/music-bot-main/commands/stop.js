import { SlashCommandBuilder } from 'discord.js';
import { distube } from '../client.js'; // Importa distube desde client.js
import { EmbedBuilder } from 'discord.js';

export default {
    data: new SlashCommandBuilder()
        .setName('stop')
        .setDescription('Stops the music and clears the queue'),
    async execute(interaction) {
        await interaction.deferReply();

        // Obtener la cola de reproducción
        const queue = distube.getQueue(interaction.guildId);

        // Verificar si no hay música reproduciéndose
        if (!queue) {
            return interaction.editReply({
                content: '❌ There is no music playing right now!',
                ephemeral: true // Este mensaje solo lo verá el usuario que ejecutó el comando
            });
        }

        try {
            // Detener la música y limpiar la cola
            queue.stop();

            // Crear un embed para una mejor presentación
            const embed = new EmbedBuilder()
                .setColor('#FF0000') // Color rojo para indicar que se detuvo
                .setTitle('⏹️ Music Stopped')
                .setDescription('The music has been stopped and the queue has been cleared.')
                .setFooter({ text: `Command executed by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            // Editar la respuesta con el embed
            interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('Error stopping the music:', error);

            // Responder con un mensaje de error
            interaction.editReply({
                content: '🚨 An error occurred while trying to stop the music. Please try again later.',
                ephemeral: true
            });
        }
    },
};
