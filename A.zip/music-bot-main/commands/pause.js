import { SlashCommandBuilder } from 'discord.js';
import { distube } from '../client.js';

export default {
    data: new SlashCommandBuilder()
        .setName('pause')
        .setDescription('Pauses the currently playing song'),
    async execute(interaction) {
        await interaction.deferReply();

        const queue = distube.getQueue(interaction.guildId);
        if (!queue) {
            return interaction.editReply({
                content: '❌ There is no music playing currently.',
                ephemeral: true // Este mensaje solo lo verá el usuario que ejecutó el comando
            });
        }

        try {
            distube.pause(interaction.guildId);
            interaction.editReply({
                content: '⏸️ Music paused.',
                ephemeral: true // Este mensaje solo lo verá el usuario que ejecutó el comando
            });
        } catch (error) {
            console.error('Error pausing the song:', error);
            interaction.editReply({
                content: '🚨 An error occurred while trying to pause the music. Please try again later.',
                ephemeral: true
            });
        }
    },
};
