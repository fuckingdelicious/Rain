import { SlashCommandBuilder } from 'discord.js';
import { distube } from '../client.js';

export default {
    data: new SlashCommandBuilder()
        .setName('resume')
        .setDescription('Resumes the currently paused song'),
    async execute(interaction) {
        await interaction.deferReply();

        const queue = distube.getQueue(interaction.guildId);
        if (!queue) {
            return interaction.editReply({
                content: '❌ There is no music playing currently.',
                ephemeral: true // Este mensaje solo lo verá el usuario que ejecutó el comando
            });
        }

        try {
            distube.resume(interaction.guildId);
            interaction.editReply({
                content: '▶️ Music resumed.',
                ephemeral: true // Este mensaje solo lo verá el usuario que ejecutó el comando
            });
        } catch (error) {
            console.error('Error resuming the song:', error);
            interaction.editReply({
                content: '🚨 An error occurred while trying to resume the music. Please try again later.',
                ephemeral: true
            });
        }
    },
};
