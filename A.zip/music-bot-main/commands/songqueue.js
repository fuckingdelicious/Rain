import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { distube } from '../client.js';

export default {
    data: new SlashCommandBuilder()
        .setName('songqueue')
        .setDescription('Displays the current song queue'),
    async execute(interaction) {
        await interaction.deferReply();

        const queue = distube.getQueue(interaction.guildId);
        if (!queue) {
            return interaction.editReply({
                content: '❌ There is no music playing currently.',
                ephemeral: true // Este mensaje solo lo verá el usuario que ejecutó el comando
            });
        }

        try {
            const songQueue = queue.songs.map((song, index) => `${index + 1}. [${song.name}](${song.url}) - \`${song.formattedDuration}\``).join('\n');
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🎵 Song Queue')
                .setDescription(songQueue || 'No songs in the queue.')
                .setTimestamp();

            interaction.editReply({ embeds: [embed] });
        } catch (error) {
            console.error('Error displaying the song queue:', error);
            interaction.editReply({
                content: '🚨 An error occurred while trying to display the song queue. Please try again later.',
                ephemeral: true
            });
        }
    },
};
