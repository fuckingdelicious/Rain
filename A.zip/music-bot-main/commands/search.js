import { SlashCommandBuilder } from 'discord.js';

export default {
    data: new SlashCommandBuilder()
        .setName('search')
        .setDescription('Search for a music')
        .addStringOption(option => 
            option.setName('query')
                .setDescription('The query to search for')
                .setRequired(true)),
    async execute(interaction) {
        interaction.reply('searching...');
        console.log('search command');
    },
};
