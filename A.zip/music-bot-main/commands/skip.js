import { SlashCommandBuilder } from 'discord.js';
import { distube } from '../client.js'; // Importa distube desde client.js
import { EmbedBuilder } from 'discord.js';

export default {
    data: new SlashCommandBuilder()
        .setName('skip')
        .setDescription('Skips the current song'),
    async execute(interaction) {
        try {
            // Defer the reply to prevent interaction timeout
            await interaction.deferReply();

            // Obtener la cola de reproducción
            const queue = distube.getQueue(interaction.guildId);

            // Verificar si no hay música reproduciéndose
            if (!queue || !queue.songs || queue.songs.length === 0) {
                return interaction.editReply({
                    content: '❌ There is no music playing right now!',
                    ephemeral: true // Este mensaje solo lo verá el usuario que ejecutó el comando
                });
            }

            // Guardar la canción que se va a saltar
            const skippedSong = queue.songs[0];

            // Verificar si hay más canciones en la cola después de la actual
            if (queue.songs.length === 1) {
                // Si esta es la única canción, detén la cola
                queue.stop();
                return interaction.editReply({
                    content: `⏹️ Skipped the current song: **${skippedSong.name}**. There are no more songs in the queue, stopping the playback.`,
                    ephemeral: false
                });
            }

            // Saltar la canción actual
            await queue.skip();  // Usa await para asegurarte de que el skip se complete antes de seguir

            // Crear un embed para la respuesta
            const embed = new EmbedBuilder()
                .setColor('#0099FF') // Azul para indicar una acción de progreso
                .setTitle('⏭️ Song Skipped')
                .setDescription(`Skipped: [${skippedSong.name}](${skippedSong.url})`)
                .setThumbnail(skippedSong.thumbnail)
                .addFields(
                    { name: 'Duration', value: skippedSong.formattedDuration, inline: true },
                    { name: 'Requested by', value: skippedSong.user.tag, inline: true }
                )
                .setFooter({ text: `Command executed by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            // Responder con el embed
            interaction.editReply({ embeds: [embed] });

        } catch (error) {
            // Captura del error específico de DisTube
            if (error.errorCode === 'NO_UP_NEXT') {
                console.error('No next song available:', error);

                // Enviar un mensaje claro si no hay siguiente canción
                return interaction.editReply({
                    content: '🚫 There is no next song to skip to, so playback has been stopped.',
                    ephemeral: true
                });
            }

            // Manejo de otros errores
            console.error('Error skipping the song:', error);

            // Responder con un mensaje de error
            interaction.editReply({
                content: '🚨 An unexpected error occurred while trying to skip the song. Please try again later.',
                ephemeral: true
            });
        }
    },
};
