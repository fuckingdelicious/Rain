import {
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} from 'discord.js';
import { client, distube } from '../client.js';

export default {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription('Plays a song from YouTube')
        .addStringOption(option =>
            option.setName('query')
                .setDescription('The URL or search query of the YouTube video or playlist')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply();

        const query = interaction.options.getString('query');
        const voiceChannel = interaction.member.voice.channel;

        // Verificar si el usuario está en un canal de voz
        if (!voiceChannel) {
            return interaction.editReply({
                content: '❌ You need to be in a voice channel to play music!',
                ephemeral: true // Este mensaje solo lo verá el usuario que ejecutó el comando
            });
        }

        try {
            // Intentar reproducir la canción
            await distube.play(voiceChannel, query, {
                member: interaction.member,
                textChannel: interaction.channel,
            });

            const queue = distube.getQueue(interaction.guildId);

            if (!queue || queue.songs.length === 0) {
                return interaction.editReply({
                    content: 'An error occurred while trying to add the song to the queue. Please try again later.',
                    ephemeral: true
                });
            }

            // Comprobar si hay más de una canción en la cola
            if (queue.songs.length > 1) {
                // Si hay más de una canción, se ha añadido a la cola
                const song = queue.songs[queue.songs.length - 1]; // Última canción añadida

                const embedQueue = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('Added to Queue')
                    .setDescription(`🎵 **${song.name}** - \`${song.formattedDuration}\`\n\n🔗 [YouTube Link](${song.url})`)
                    .addFields(
                        { name: 'Duration', value: song.formattedDuration, inline: true },
                        { name: 'Requested by', value: interaction.user.tag, inline: true },
                    )
                    .setThumbnail(song.thumbnail)
                    .setTimestamp();

                return interaction.editReply({ embeds: [embedQueue] });
            }

            // Obtener la primera canción de la cola (la que está sonando ahora)
            const song = queue.songs[0];

            if (!song) {
                return interaction.editReply({
                    content: 'An error occurred while trying to play the song. Please try again later.',
                    ephemeral: true // Este mensaje solo lo verá el usuario que ejecutó el comando
                });
            }

            const embed = new EmbedBuilder()
                .setColor('#FF5733') // Color llamativo para destacar
                .setTitle('🎵 Now Playing')
                .setDescription(`[${song.name}](${song.url})`)
                .addFields(
                    { name: 'Duration', value: song.formattedDuration || 'Unknown', inline: true },
                    { name: 'Requested by', value: interaction.user.tag, inline: true },
                    { name: 'Artist', value: song.uploader.name || 'Unknown', inline: true }, // Información del artista
                    { name: 'Channel', value: song.uploader.url || 'Unknown', inline: true } // Información del canal
                )
                .setThumbnail(song.thumbnail)
                .setFooter({ text: 'Enjoy your music!', iconURL: interaction.user.displayAvatarURL() }) // Usar el avatar del usuario como icono
                .setTimestamp();

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('pause')
                        .setLabel('Pause')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('⏸️'),
                    new ButtonBuilder()
                        .setCustomId('resume')
                        .setLabel('Resume')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('▶️'),
                    new ButtonBuilder()
                        .setCustomId('stop')
                        .setLabel('Stop')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('⏹️'),
                    new ButtonBuilder()
                        .setCustomId('skip')
                        .setLabel('Skip')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('⏭️'),
                    new ButtonBuilder()
                        .setCustomId('shuffle')
                        .setLabel('Shuffle')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🔀'),
                );

            // Responder con el embed y los botones
            interaction.editReply({ embeds: [embed], components: [row] });

        } catch (error) {
            console.error('Error playing the song:', error);
            interaction.editReply({
                content: '🚨 An error occurred while trying to play the song. Please check the URL or query and try again.',
                ephemeral: true
            });
        }
    },
};
