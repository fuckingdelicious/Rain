import { Collection } from 'discord.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { deployCommands } from './deployCommands.js';
import { client } from './client.js'; // Importa el cliente desde client.js

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const eventFiles = fs.readdirSync(path.join(__dirname, 'events')).filter(file => file.endsWith('.js') || file.endsWith('.mjs'));

client.commands = new Collection();
const commandFiles = fs.readdirSync(path.join(__dirname, 'commands')).filter(file => file.endsWith('.js') || file.endsWith('.mjs'));

for (const file of commandFiles) {
    import(`./commands/${file}`).then(command => {
        client.commands.set(command.default.data.name, command);
    });
}

for (const file of eventFiles) {
    import(`./events/${file}`).then(event => {
        console.log(`Loaded event ${event.default.name}`);
        if (event.default.once) {
            client.once(event.default.name, (...args) => event.default.execute(...args));
        } else {
            client.on(event.default.name, (...args) => event.default.execute(...args));
        }
    });
}

deployCommands();
